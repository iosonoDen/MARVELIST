import { useEffect, useRef, useState } from 'react';
import { count, filter, makeList, parseSaved, storageKey } from './model';
import type { Film, Progress, Saved, Sort, Status } from './model';
import imported from './tmdb.json';

type Extra = { poster?: string; description?: string; year?: string; runtime?: number; genres?: string[] };
const tmdb: Record<string, Extra> = imported;
const roman = ['I', 'II', 'III', 'IV', 'V', 'VI'];
const tmdbLink = (id: number) => `https://www.themoviedb.org/movie/${id}?language=it-IT`;

function readLocal() {
  try { return { progress: parseSaved(localStorage.getItem(storageKey)), blocked: false }; }
  catch { return { progress: {}, blocked: true }; }
}

function Poster({ film }: { film: Film }) {
  const [failed, fail] = useState(false);
  const src = tmdb[film.id]?.poster;
  return <span className="cover" data-phase={film.phase} aria-hidden="true">
    {src && !failed ? <img src={src} alt="" loading="lazy" onError={() => fail(true)} /> : <span>{roman[film.phase - 1]}</span>}
  </span>;
}

function FilmDialog({ film, onClose, update }: { film: Film; onClose: () => void; update: (patch: Partial<Progress>) => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const details = tmdb[film.id];
  useEffect(() => {
    const el = ref.current;
    if (el && !el.open) { el.showModal(); closeRef.current?.focus(); }
  }, []);
  return <dialog ref={ref} className="film-dialog" aria-labelledby="film-title" onClose={onClose}
    onClick={(event) => { if (event.target === event.currentTarget) event.currentTarget.close(); }}>
    <article className="dialog-content">
      <header className="dialog-header">
        <p className="mono">Scheda film / {String(film.index).padStart(2, '0')}</p>
        <button ref={closeRef} type="button" className="close" aria-label="Chiudi scheda" onClick={() => ref.current?.close()}>×</button>
      </header>
      <div className="dialog-title">
        <Poster film={film} />
        <div className="min-w-0">
          <p className="mono phase-text">Fase {roman[film.phase - 1]}</p>
          <h2 id="film-title">{film.title}</h2>
          {details?.genres?.length ? <p className="text-sm text-muted mt-2">{details.genres.join(' / ')}</p> : null}
        </div>
      </div>
      <dl className="facts">
        <div><dt>Ambientazione nel foglio</dt><dd>{film.timeline}</dd></div>
        {details?.year && <div><dt>Anno di uscita</dt><dd>{details.year}</dd></div>}
        {details?.runtime ? <div><dt>Durata</dt><dd>{details.runtime} min</dd></div> : null}
      </dl>
      <section className="synopsis" aria-labelledby="synopsis-title">
        <h3 id="synopsis-title" className="mono">Trama breve</h3>
        <p>{details?.description || film.plot}</p>
      </section>
      <section className="personal" aria-label="Progresso personale">
        <div className="personal-line">
          <label className="inline-flex items-center gap-2 font-semibold">
            <input type="checkbox" checked={film.watched} onChange={(e) => update({ watched: e.target.checked })} /> Visto
          </label>
          <label className="inline-flex items-center gap-2 text-sm font-semibold" htmlFor="rating">
            Voto <select id="rating" value={film.rating} onChange={(e) => update({ rating: Number(e.target.value) })}>
              <option value="0">Senza voto</option>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} / 5</option>)}
            </select>
          </label>
        </div>
        <label htmlFor="notes" className="block font-semibold text-sm">Note personali</label>
        <textarea id="notes" rows={2} placeholder="Aggiungi una nota…" value={film.notes} onChange={(e) => update({ notes: e.target.value })} />
      </section>
      <a className="tmdb-link" href={tmdbLink(film.tmdbId)} target="_blank" rel="noreferrer">Scheda su TMDB ↗</a>
    </article>
  </dialog>;
}

export default function App() {
  const [initial] = useState(readLocal);
  const [saved, setSaved] = useState<Saved>(initial.progress);
  const [changed, setChanged] = useState(false);
  const [writeError, setWriteError] = useState(false);
  const [status, setStatus] = useState<Status>('all');
  const [query, setQuery] = useState('');
  const [phase, setPhase] = useState(0);
  const [sort, setSort] = useState<Sort>('sheet');
  const [selected, setSelected] = useState<string | null>(null);
  const filtersRef = useRef<HTMLInputElement>(null);
  const opener = useRef<HTMLButtonElement | null>(null);
  const list = makeList(saved);
  const totals = count(list);
  const results = filter(list, { query, phase, status, sort });
  const activeFilm = list.find((movie) => movie.id === selected);

  useEffect(() => {
    if (!changed || initial.blocked) return;
    try { localStorage.setItem(storageKey, JSON.stringify(saved)); setWriteError(false); }
    catch { setWriteError(true); }
  }, [saved, changed, initial.blocked]);

  function update(id: string, patch: Partial<Progress>) {
    setSaved((current) => ({ ...current, [id]: { ...current[id], ...patch } }));
    setChanged(true);
  }

  function dismiss() {
    setSelected(null);
    if (opener.current?.isConnected) opener.current.focus();
    else filtersRef.current?.focus();
  }

  return <>
    <a href="#catalog" className="skip">Vai ai film</a>
    <header className="mast shell">
      <div className="flex items-center gap-3"><span className="mast-symbol" aria-hidden="true">M</span><span className="mast-title">Marvel Cinematic Universe</span></div>
      <span className="mono text-muted mast-caption">Checklist personale</span>
    </header>
    <main className="shell">
      <section className="intro" aria-labelledby="page-title">
        <div><h1 id="page-title">Film in ordine<span>.</span></h1><p>I film del MCU nella sequenza del tuo foglio.</p></div>
        <div className="progress-box">
          <div className="progress-label"><span>Visti <strong>{totals.seen}/{totals.total}</strong></span><span>{totals.pct}%</span></div>
          <progress aria-label="Film visti" value={totals.seen} max={totals.total} />
        </div>
      </section>
      {(initial.blocked || writeError) && <p role="alert" className="warning">{initial.blocked ? 'Impossibile leggere i progressi salvati. Le modifiche restano in questa sessione.' : 'Salvataggio non riuscito: le modifiche potrebbero andare perse alla ricarica.'}</p>}
      <section id="catalog" aria-label="Catalogo dei film" tabIndex={-1}>
        <div className="toolbar">
          <div className="status-filters" role="group" aria-label="Stato visione">
            {([['all', 'Tutti'], ['unwatched', 'Da vedere'], ['watched', 'Visti']] as const).map(([value, label]) =>
              <button type="button" key={value} aria-pressed={status === value} onClick={() => setStatus(value)}>{label}</button>)}
          </div>
          <div className="tools">
            <input type="search" ref={filtersRef} aria-label="Cerca per titolo o ambientazione" placeholder="Cerca un film…" value={query} onChange={(e) => setQuery(e.target.value)} />
            <select aria-label="Fase" value={phase} onChange={(e) => setPhase(Number(e.target.value))}>
              <option value={0}>Tutte le fasi</option>
              {roman.map((name, i) => <option key={name} value={i + 1}>Fase {name}</option>)}
            </select>
            <select aria-label="Ordinamento" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
              <option value="sheet">Ordine del foglio</option><option value="title">Titolo A–Z</option><option value="rating">Voto più alto</option>
            </select>
          </div>
        </div>
        <p className="result-count mono" role="status">{results.length} {results.length === 1 ? 'titolo' : 'titoli'}</p>
        {results.length ? <ol className="list" aria-label="Film MCU">
          {results.map((film) => <li className="movie" key={film.id}>
            <button type="button" className="row" aria-haspopup="dialog" onClick={(e) => { opener.current = e.currentTarget; setSelected(film.id); }}>
              <span className="index mono" aria-hidden="true">{String(film.index).padStart(2, '0')}</span>
              <Poster film={film} />
              <span className="row-text">
                <span className="row-title">{film.title}</span>
                <span className="row-meta"><span>Fase {roman[film.phase - 1]}</span><span aria-hidden="true"> · </span><span>{film.timeline}</span></span>
              </span>
              {film.rating > 0 && <span className="row-rating" aria-label={`Voto ${film.rating} su 5`}><span aria-hidden="true">★ </span>{film.rating}<span className="text-muted">/5</span></span>}
              <span className="row-arrow" aria-hidden="true">→</span>
            </button>
            <label className="row-check" title={film.watched ? 'Segna come da vedere' : 'Segna come visto'}>
              <input type="checkbox" checked={film.watched} aria-label={`${film.title}: visto`} onChange={(e) => update(film.id, { watched: e.target.checked })} />
            </label>
          </li>)}
        </ol> : <div className="empty">
          <p>Nessun film corrisponde ai filtri.</p>
          <button type="button" onClick={() => { setQuery(''); setPhase(0); setStatus('all'); setSort('sheet'); }}>Azzera i filtri</button>
        </div>}
      </section>
      <footer className="footer">
        <p>Progressi salvati in questo browser.</p>
        {Object.keys(tmdb).length > 0 && <div className="credits"><a href="https://www.themoviedb.org/about/logos-attribution" target="_blank" rel="noreferrer"><img width="34" height="27" alt="The Movie Database" src="https://www.themoviedb.org/assets/2/v4/logos/v2/blue_square_2-d537fb228cf3ded904ef09b136fe3fec72548ebc1fea3fbbd1ad9e36364db38b.svg" /></a><p>This product uses the TMDB API but is not endorsed or certified by TMDB.</p></div>}
      </footer>
    </main>
    {activeFilm && <FilmDialog key={activeFilm.id} film={activeFilm} onClose={dismiss} update={(patch) => update(activeFilm.id, patch)} />}
  </>;
}
