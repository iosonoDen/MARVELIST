import films from './films.json';

export type Progress = { watched: boolean; rating: number; notes: string };
export type Film = (typeof films)[number];
export type Saved = Partial<Record<string, Partial<Progress>>>;
export type Status = 'all' | 'unwatched' | 'watched';
export type Sort = 'sheet' | 'title' | 'rating';
export const storageKey = 'mcu-checklist:progress:v1';

export function parseSaved(raw: string | null): Saved {
  if (raw === null) return {};
  const parsed: unknown = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Invalid data');
  const input = parsed as Record<string, unknown>;
  const data: Saved = {};
  for (const { id } of films) {
    const value = input[id];
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const { watched, rating, notes } = value as Record<string, unknown>;
    data[id] = {
      ...(typeof watched === 'boolean' ? { watched } : {}),
      ...(typeof rating === 'number' && Number.isInteger(rating) && rating >= 0 && rating <= 5 ? { rating } : {}),
      ...(typeof notes === 'string' ? { notes } : {}),
    };
  }
  return data;
}

export function makeList(saved: Saved): Film[] {
  return films.map((film) => ({ ...film, ...saved[film.id] }));
}

export function count(list: readonly Film[]) {
  const seen = list.filter((film) => film.watched).length;
  return { seen, total: list.length, pct: list.length ? Math.round(100 * seen / list.length) : 0 };
}

export function filter(list: readonly Film[], { query, phase, status, sort }: { query: string; phase: number; status: Status; sort: Sort }) {
  const term = query.trim().toLocaleLowerCase('it');
  const output = list.filter((film) => (!phase || film.phase === phase) &&
    (status === 'all' || film.watched === (status === 'watched')) &&
    (!term || `${film.title} ${film.timeline}`.toLocaleLowerCase('it').includes(term)));
  if (sort === 'title') output.sort((a, b) => a.title.localeCompare(b.title, 'it'));
  if (sort === 'rating') output.sort((a, b) => b.rating - a.rating || a.index - b.index);
  return output;
}
