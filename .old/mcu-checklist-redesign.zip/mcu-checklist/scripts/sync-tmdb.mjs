import { readFile, writeFile, rename } from 'node:fs/promises';

const token = process.env.TMDB_READ_TOKEN?.trim();
const filmsPath = new URL('../src/films.json', import.meta.url);
const detailsPath = new URL('../src/tmdb.json', import.meta.url);
const tempPath = new URL(`../src/tmdb.${process.pid}.tmp`, import.meta.url);
const filePattern = /^\/[a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp)$/;

async function request(path) {
  const response = await fetch(`https://api.themoviedb.org/3${path}`, {
    headers: { Accept: 'application/json', Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

async function sync() {
  if (!token) throw new Error('Imposta TMDB_READ_TOKEN in .env.local.');
  const films = JSON.parse(await readFile(filmsPath, 'utf8'));
  const old = JSON.parse(await readFile(detailsPath, 'utf8'));
  const { images } = await request('/configuration');
  const base = new URL(images.secure_base_url);
  if (base.origin !== 'https://image.tmdb.org') throw new Error('URL CDN inatteso.');
  const size = ['w342', 'w500', 'w185'].find((item) => images.poster_sizes.includes(item));
  if (!size) throw new Error('Nessun formato di locandina compatibile.');
  const output = new Map();
  let failures = 0;
  for (let i = 0; i < films.length; i += 4) {
    await Promise.all(films.slice(i, i + 4).map(async (film) => {
      try {
        const item = await request(`/movie/${film.tmdbId}?language=it-IT`);
        const entry = {};
        if (typeof item.poster_path === 'string' && filePattern.test(item.poster_path)) entry.poster = new URL(`${size}${item.poster_path}`, base).href;
        if (typeof item.overview === 'string' && item.overview.trim()) entry.description = item.overview.trim();
        if (typeof item.release_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(item.release_date)) entry.year = item.release_date.slice(0, 4);
        if (Number.isInteger(item.runtime) && item.runtime > 0) entry.runtime = item.runtime;
        if (Array.isArray(item.genres)) entry.genres = item.genres.map((genre) => genre?.name).filter((name) => typeof name === 'string');
        if (Object.keys(entry).length) output.set(film.id, entry);
      } catch (err) {
        failures++;
        if (old[film.id]) output.set(film.id, old[film.id]);
        console.warn(`${film.title}: ${err.message}`);
      }
    }));
  }
  const cache = Object.fromEntries(films.filter((film) => output.has(film.id)).map((film) => [film.id, output.get(film.id)]));
  await writeFile(tempPath, JSON.stringify(cache, null, 2) + '\n');
  await rename(tempPath, detailsPath);
  console.log(`Dettagli salvati: ${output.size}/${films.length}. Errori: ${failures}.`);
  if (failures) process.exitCode = 1;
}

sync().catch((err) => { console.error(err.message); process.exitCode = 1; });
