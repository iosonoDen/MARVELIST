# MCU — Film in ordine

Checklist locale con React, TypeScript, Tailwind CSS e Vite. Richiede Node.js 22.12 o superiore.

```sh
npm install
npm run dev
```

Apri `http://localhost:5173`. Se avevi già usato la prima versione, usa lo stesso browser, profilo, indirizzo e porta per ritrovare i tuoi progressi. Non serve il vecchio ZIP, non serve copiare i file e l’Excel non viene modificato.

## Catalogo

Clicca una riga per vedere ambientazione, fase e trama breve, oppure per modificare voto e note. Chiudi con Escape o con il pulsante ×. La spunta a destra è indipendente dalla riga e aggiorna subito il contatore senza aprire la scheda. L’ordine e le ambientazioni iniziali provengono dal foglio; il campo ambientazione non indica la data di uscita.

## TMDB (facoltativo)

Le trame brevi locali e i segnaposto sono già inclusi. Per avere locandine, descrizioni TMDB in italiano, anno di uscita, durata e generi quando disponibili:

```sh
cp .env.example .env.local
# Inserisci il tuo API Read Access Token TMDB in .env.local
npm run posters
```

I metadati vengono salvati in `src/tmdb.json`; le immagini sono caricate dal CDN TMDB. Per i campi mancanti, l’app usa i dati locali o non mostra il campo. Il token rimane nello script Node; non usare il prefisso `VITE_`. Puoi riutilizzare il `.env.local` della versione precedente. Non servono credenziali per usare la lista o il popup.

## Verifica

```sh
npm test
npm run build
```

Nel browser, apri una riga, cambia voto, scrivi una nota, chiudi con Escape e ricarica. I dati dovrebbero restare salvati. Prova anche a spuntare un film direttamente dalla lista: il popup non deve aprirsi.
