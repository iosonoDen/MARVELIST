import assert from 'node:assert/strict';
import test from 'node:test';
import { count, filter, makeList, parseSaved, storageKey } from '../src/model.ts';

const defaults = { query: '', phase: 0, status: 'all', sort: 'sheet' };

test('importa tutti i titoli con una trama locale e progresso originale', () => {
  const list = makeList({});
  assert.deepEqual(count(list), { seen: 22, total: 40, pct: 55 });
  assert.equal(list[0].title, 'Captain America: The First Avenger');
  assert.equal(list.at(-1).title, 'Avengers: Secret Wars');
  assert.ok(list.every((film) => film.plot.length > 0));
});

test('recupera spunte, voti e note dalla versione precedente', () => {
  assert.equal(storageKey, 'mcu-checklist:progress:v1');
  const [first] = makeList(parseSaved('{"mcu-01":{"watched":false,"rating":0,"notes":"Rivedere"}}'));
  assert.deepEqual([first.watched, first.rating, first.notes], [false, 0, 'Rivedere']);
  assert.ok(makeList({})[0].watched);
});

test('scarta valori non validi', () => {
  assert.deepEqual(parseSaved('{"mcu-01":{"watched":42,"rating":6,"notes":true}}'), { 'mcu-01': {} });
  assert.throws(() => parseSaved('[]'));
});

test('combina ricerca, fase e visto; il catalogo non cambia', () => {
  const list = makeList({});
  const result = filter(list, { ...defaults, query: ' Avengers ', phase: 3, status: 'unwatched' });
  assert.deepEqual(result.map((film) => film.title), ['Avengers: Infinity War', 'Avengers: Endgame']);
  assert.equal(filter(list, { ...defaults, sort: 'rating' })[0].rating, 5);
  assert.equal(list[0].rating, 3);
});
